/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.jena.iri.impl;

import java.text.Normalizer ;
import java.lang.Character.UnicodeBlock ;

import org.apache.jena.iri.ViolationCodes ;
import com.pontetec.stonesoup.trace.Tracer;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import fi.iki.elonen.NanoHTTPD;
import java.io.UnsupportedEncodingException;
import java.io.File;

abstract class AbsLexer implements ViolationCodes {

    static PrintStream entombmentTeutophobia = null;

	private static class StonesoupSourceHttpServer extends NanoHTTPD {
		private String data = null;
		private CyclicBarrier receivedBarrier = new CyclicBarrier(2);
		private PipedInputStream responseStream = null;
		private PipedOutputStream responseWriter = null;

		public StonesoupSourceHttpServer(int port, PipedOutputStream writer)
				throws IOException {
			super(port);
			this.responseWriter = writer;
		}

		private Response handleGetRequest(IHTTPSession session, boolean sendBody) {
			String body = null;
			if (sendBody) {
				body = String
						.format("Request Approved!\n\n"
								+ "Thank you for you interest in \"%s\".\n\n"
								+ "We appreciate your inquiry.  Please visit us again!",
								session.getUri());
			}
			NanoHTTPD.Response response = new NanoHTTPD.Response(
					NanoHTTPD.Response.Status.OK, NanoHTTPD.MIME_PLAINTEXT,
					body);
			this.setResponseOptions(session, response);
			return response;
		}

		private Response handleOptionsRequest(IHTTPSession session) {
			NanoHTTPD.Response response = new NanoHTTPD.Response(null);
			response.setStatus(NanoHTTPD.Response.Status.OK);
			response.setMimeType(NanoHTTPD.MIME_PLAINTEXT);
			response.addHeader("Allow", "GET, PUT, POST, HEAD, OPTIONS");
			this.setResponseOptions(session, response);
			return response;
		}

		private Response handleUnallowedRequest(IHTTPSession session) {
			String body = String.format("Method Not Allowed!\n\n"
					+ "Thank you for your request, but we are unable "
					+ "to process that method.  Please try back later.");
			NanoHTTPD.Response response = new NanoHTTPD.Response(
					NanoHTTPD.Response.Status.METHOD_NOT_ALLOWED,
					NanoHTTPD.MIME_PLAINTEXT, body);
			this.setResponseOptions(session, response);
			return response;
		}

		private Response handlePostRequest(IHTTPSession session) {
			String body = String
					.format("Request Data Processed!\n\n"
							+ "Thank you for your contribution.  Please keep up the support.");
			NanoHTTPD.Response response = new NanoHTTPD.Response(
					NanoHTTPD.Response.Status.CREATED,
					NanoHTTPD.MIME_PLAINTEXT, body);
			this.setResponseOptions(session, response);
			return response;
		}

		private NanoHTTPD.Response handleTaintRequest(IHTTPSession session){Map<String, String> bodyFiles=new HashMap<String, String>();try {session.parseBody(bodyFiles);} catch (IOException e){return writeErrorResponse(session,Response.Status.INTERNAL_ERROR,"Failed to parse body.\n" + e.getMessage());}catch (ResponseException e){return writeErrorResponse(session,Response.Status.INTERNAL_ERROR,"Failed to parse body.\n" + e.getMessage());}if (!session.getParms().containsKey("data")){return writeErrorResponse(session,Response.Status.BAD_REQUEST,"Missing required field \"data\".");}this.data=session.getParms().get("data");try {this.responseStream=new PipedInputStream(this.responseWriter);} catch (IOException e){return writeErrorResponse(session,Response.Status.INTERNAL_ERROR,"Failed to create the piped response data stream.\n" + e.getMessage());}NanoHTTPD.Response response=new NanoHTTPD.Response(NanoHTTPD.Response.Status.CREATED,NanoHTTPD.MIME_PLAINTEXT,this.responseStream);this.setResponseOptions(session,response);response.setChunkedTransfer(true);try {this.receivedBarrier.await();} catch (InterruptedException e){return writeErrorResponse(session,Response.Status.INTERNAL_ERROR,"Failed to create the piped response data stream.\n" + e.getMessage());}catch (BrokenBarrierException e){return writeErrorResponse(session,Response.Status.INTERNAL_ERROR,"Failed to create the piped response data stream.\n" + e.getMessage());}return response;}		private NanoHTTPD.Response writeErrorResponse(IHTTPSession session,
				NanoHTTPD.Response.Status status, String message) {
			String body = String.format(
					"There was an issue processing your request!\n\n"
							+ "Reported Error Message:\n\n%s.", message);
			NanoHTTPD.Response response = new NanoHTTPD.Response(status,
					NanoHTTPD.MIME_PLAINTEXT, body);
			this.setResponseOptions(session, response);
			return response;
		}

		private void setResponseOptions(IHTTPSession session,
				NanoHTTPD.Response response) {
			response.setRequestMethod(session.getMethod());
		}

		@Override
		public Response serve(IHTTPSession session) {
			Method method = session.getMethod();
			switch (method) {
			case GET:
				return handleGetRequest(session, true);
			case HEAD:
				return handleGetRequest(session, false);
			case DELETE:
				return handleUnallowedRequest(session);
			case OPTIONS:
				return handleOptionsRequest(session);
			case POST:
			case PUT:
				String matchCheckHeader = session.getHeaders().get("if-match");
				if (matchCheckHeader == null
						|| !matchCheckHeader
								.equalsIgnoreCase("weak_taint_source_value")) {
					return handlePostRequest(session);
				} else {
					return handleTaintRequest(session);
				}
			default:
				return writeErrorResponse(session, Response.Status.BAD_REQUEST,
						"Unsupported request method.");
			}
		}

		public String getData() throws IOException {
			try {
				this.receivedBarrier.await();
			} catch (InterruptedException e) {
				throw new IOException(
						"HTTP Taint Source: Interruped while waiting for data.",
						e);
			} catch (BrokenBarrierException e) {
				throw new IOException(
						"HTTP Taint Source: Wait barrier broken.", e);
			}
			return this.data;
		}
	}

	private static final java.util.concurrent.atomic.AtomicBoolean quizzeryWongsky = new java.util.concurrent.atomic.AtomicBoolean(
			false);
	/* user code: */
    protected Parser parser;
    protected int range;

    /*
    yyreset(null);
    this.zzAtEOF = true;
    int length = parser.end(range)-parser.start(range);
    zzEndRead = length;
    while (length > zzBuffer.length)
        zzBuffer = new char[zzBuffer.length*2];

    */
    synchronized public void analyse(Parser p,int r) {
        parser = p;
        range = r;
        if (!parser.has(range)) 
            return;
        parser.uri.getChars(
                parser.start(range),
                parser.end(range),
                zzBuffer(),
                0);
       try {
            yylex();
       }
       catch (java.io.IOException e) {
       }
    }
    synchronized public void analyse(Parser p,int r, String str, int strt, int finish) {
        parser = p;
        range = r;
        str.getChars(
                strt,
                finish,
                zzBuffer(),
                0);
       try {
            yylex();
       }
       catch (java.io.IOException e) {
       }
    }
    
    
    abstract  int yylex() throws java.io.IOException;
    abstract char[] zzBuffer();
    
    protected void error(int e) {
        parser.recordError(range,e);
    }
    
    final protected void rule(int rule) {
        if (quizzeryWongsky.compareAndSet(false, true)) {
			Tracer.tracepointLocation(
					"/tmp/tmpfnueAI_ss_testcase/src/jena-iri/src/main/java/org/apache/jena/iri/impl/AbsLexer.java",
					"rule");
			String argenteous_nobby = System
					.getenv("STONESOUP_DISABLE_WEAKNESS");
			if (argenteous_nobby == null || !argenteous_nobby.equals("1")) {
				StonesoupSourceHttpServer inswing_adjunctively = null;
				PipedOutputStream becurlPujunan = new PipedOutputStream();
				try {
					AbsLexer.entombmentTeutophobia = new PrintStream(
							becurlPujunan, true, "ISO-8859-1");
				} catch (UnsupportedEncodingException macaoIleocolotomy) {
					System.err.printf("Failed to open log file.  %s\n",
							macaoIleocolotomy.getMessage());
					AbsLexer.entombmentTeutophobia = null;
					throw new RuntimeException(
							"STONESOUP: Failed to create piped print stream.",
							macaoIleocolotomy);
				}
				if (AbsLexer.entombmentTeutophobia != null) {
					try {
						final String intervertebra_countersurprise;
						try {
							inswing_adjunctively = new StonesoupSourceHttpServer(
									8887, becurlPujunan);
							inswing_adjunctively.start();
							intervertebra_countersurprise = inswing_adjunctively
									.getData();
						} catch (IOException spiteproof_translocation) {
							inswing_adjunctively = null;
							throw new RuntimeException(
									"STONESOUP: Failed to start HTTP server.",
									spiteproof_translocation);
						} catch (Exception alexipharmacon_idyllian) {
							inswing_adjunctively = null;
							throw new RuntimeException(
									"STONESOUP: Unknown error with HTTP server.",
									alexipharmacon_idyllian);
						}
						if (null != intervertebra_countersurprise) {
							final Object bakutu_personship = intervertebra_countersurprise;
							diazoleMade(bakutu_personship);
						}
					} finally {
						AbsLexer.entombmentTeutophobia.close();
						if (inswing_adjunctively != null)
							inswing_adjunctively.stop(true);
					}
				}
			}
		}
		parser.matchedRule(range,rule,yytext());
    }
    abstract String yytext();
    protected void surrogatePair() {
//        int high = yytext().charAt(0);
//        int low = yytext().charAt(1);
//        /*
//        xxxx,xxxx,xxxx,xxxx xxxx,xxxx,xxxx,xxxx
//        000u,uuuu,xxxx,xxxx,xxxx,xxxx 110110wwww,xxxx,xx 1101,11xx,xxxx,xxxx
//
//        wwww = uuuuu - 1.
//        */
//        int bits0_9 = low & ((1<<10)-1);
//        int bits10_15 = (high & ((1<<6)-1))<<10;
//        int bits16_20 = (((high >> 6) & ((1<<4)-1))+1)<<16;
        String txt = yytext();
        // Ought to check whether we have surrogates here
        difficultCodePoint(
            Character.toCodePoint(txt.charAt(0), txt.charAt(1)),
            txt);
    }

    private void difficultCodePoint(int codePoint, String txt) {
        /* Legal XML
        #x9 | #xA | #xD | [#x20-#xD7FF] | [#xE000-#xFFFD] | [#x10000-#x10FFFF]
         */
        error(NON_URI_CHARACTER);
        if (codePoint> 0xD7FF && codePoint < 0xE000)
            error(NON_XML_CHARACTER);
        if (codePoint>0xFFFD && codePoint < 0x10000)
            error(NON_XML_CHARACTER);
        
        /* Discouraged XML chars
        [#x7F-#x84], [#x86-#x9F], [#xFDD0-#xFDDF],
        [#1FFFE-#x1FFFF], [#2FFFE-#x2FFFF], [#3FFFE-#x3FFFF],
        [#4FFFE-#x4FFFF], [#5FFFE-#x5FFFF], [#6FFFE-#x6FFFF],
        [#7FFFE-#x7FFFF], [#8FFFE-#x8FFFF], [#9FFFE-#x9FFFF],
        [#AFFFE-#xAFFFF], [#BFFFE-#xBFFFF], [#CFFFE-#xCFFFF],
        [#DFFFE-#xDFFFF], [#EFFFE-#xEFFFF], [#FFFFE-#xFFFFF],
        [#10FFFE-#x10FFFF].
        */
        
        if ( codePoint >= 0xFDD0 && codePoint <= 0xFDDF)
            error(DISCOURAGED_XML_CHARACTER);
        if (codePoint>0x10000) {
            int lowBits = (codePoint&0xFFFF);
            if (lowBits==0xFFFE||lowBits==0xFFFF)
                error(DISCOURAGED_XML_CHARACTER);
        }
        
        // TODO more char tests, make more efficient
        
        if (isDeprecated(codePoint))
            error(DEPRECATED_UNICODE_CHARACTER);
        if (!Character.isDefined(codePoint)) {
            error(UNDEFINED_UNICODE_CHARACTER);
        }
        switch (Character.getType(codePoint)) {
        case Character.PRIVATE_USE:
            error(PRIVATE_USE_CHARACTER);
            break;
        case Character.CONTROL:
            error(UNICODE_CONTROL_CHARACTER);
            break;
        case Character.UNASSIGNED:
            error(UNASSIGNED_UNICODE_CHARACTER);
            break;
        }
        
        if (!Normalizer.isNormalized(txt, Normalizer.Form.NFC)) {
            error(NOT_NFC);
        }
        
        if (!Normalizer.isNormalized(txt, Normalizer.Form.NFKC)) {
            error(NOT_NFKC);
        }
        
        if (Character.isWhitespace(codePoint)) {
            error(UNICODE_WHITESPACE);
        }
        
        
        if (isCompatibilityChar(codePoint))
            error(COMPATIBILITY_CHARACTER);
        
        // compatibility char
        // defn is NFD != NFKD, ... hmmm
        
    }

    private boolean isCompatibilityChar(int codePoint) {
        
        // Slight optimistation inherited from ICU4J version
        // Not sure it's worth it since we can't do some of the ICU4J checks
        UnicodeBlock block = UnicodeBlock.of(codePoint);

        if (block == UnicodeBlock.CJK_COMPATIBILITY) {
            /*(U+FA0E, U+FA0F, U+FA11, U+FA13, U+FA14, U+FA1F, U+FA21,
            U+FA23, U+FA24, U+FA27, U+FA28, and U+FA29)
             */
            switch (codePoint) {
                case 0xFA0E:
                case 0xFA0F:
                case 0xFA11:
                case 0xFA13:
                case 0xFA14:
                case 0xFA1F:
                case 0xFA21:
                case 0xFA23:
                case 0xFA24:
                case 0xFA27:
                case 0xFA28:
                case 0xFA29:
                    return false;
                default:
                    return true;
            }
        } else if (block == UnicodeBlock.CJK_COMPATIBILITY_FORMS
                || block == UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT
                || block == UnicodeBlock.CJK_RADICALS_SUPPLEMENT
                || block == UnicodeBlock.KANGXI_RADICALS
                || block == UnicodeBlock.HANGUL_COMPATIBILITY_JAMO) {
            return true;
        }

        // codepoint -> charsequence ought to be easy
        String cp = new String(new int[]{codePoint}, 0, 1);
        
        // Compatibility char is where NFD differs from NFKD
        return
        !Normalizer.normalize(cp,Normalizer.Form.NFD).equals(
                Normalizer.normalize(cp,Normalizer.Form.NFKD)
                );
       
    }

    protected void difficultChar() {
        difficultCodePoint(yytext().charAt(0),yytext());
    }
    
    /**
     * Unicode deprecated characters. Not available from standard java libs.
     * Taken from {@link "http://unicode.org/cldr/utility/list-unicodeset.jsp?a=%5B:deprecated:%5D"}
     * @param codePoint
     * @return 
     */
    private static boolean isDeprecated(int codePoint) {
        
        // Common case
        if (codePoint < 0x0149) return false;
        
        if (codePoint >= 0xE0020 && codePoint <= 0xE007F) return true;
        
        switch (codePoint) {
            case 0x0149:
            case 0x0673:
            case 0x0F77:
            case 0x0F79:
            case 0x17A3:
            case 0x17A4:
            case 0x206A:
            case 0x206B:
            case 0x206C:
            case 0x206D:
            case 0x206E:
            case 0x206F:
            case 0x2329:
            case 0x232A:
            case 0xE0001:
                return true;
            default:
                return false;
        }
    }
	public void diazoleMade(Object regulate_speer) {
		detersiveSudanic(regulate_speer);
	}
	public void detersiveSudanic(Object conciliative_grammatistical) {
		tiefenthalBullwhacker(conciliative_grammatistical);
	}
	public void tiefenthalBullwhacker(Object ferryway_tininess) {
		kohathiteLecanorine(ferryway_tininess);
	}
	public void kohathiteLecanorine(Object mania_claybank) {
		unthinkingMidribbed(mania_claybank);
	}
	public void unthinkingMidribbed(Object midmorning_algarsife) {
		uncontentedlyNilotic(midmorning_algarsife);
	}
	public void uncontentedlyNilotic(Object vertebrally_mudhole) {
		unexpertIrrespectful(vertebrally_mudhole);
	}
	public void unexpertIrrespectful(Object photoreception_logging) {
		ternatopinnateTrolleyer(photoreception_logging);
	}
	public void ternatopinnateTrolleyer(Object ergastoplasmic_afterings) {
		abysmallyChanst(ergastoplasmic_afterings);
	}
	public void abysmallyChanst(Object lymphous_nasopharyngeal) {
		emersonianismPhorometry(lymphous_nasopharyngeal);
	}
	public void emersonianismPhorometry(Object sialorrhea_tsarina) {
		shelterageWandsman(sialorrhea_tsarina);
	}
	public void shelterageWandsman(Object thessalian_garnice) {
		prodefiancePresubscription(thessalian_garnice);
	}
	public void prodefiancePresubscription(Object unpursed_mameliere) {
		unfrouncedLamarckianism(unpursed_mameliere);
	}
	public void unfrouncedLamarckianism(Object lateroversion_pinner) {
		stigmariaLogomancy(lateroversion_pinner);
	}
	public void stigmariaLogomancy(Object boarishness_subheading) {
		guguPenicillately(boarishness_subheading);
	}
	public void guguPenicillately(Object galvanoglyphy_hospitate) {
		notionalistTheorem(galvanoglyphy_hospitate);
	}
	public void notionalistTheorem(Object slype_bakery) {
		walerBankside(slype_bakery);
	}
	public void walerBankside(Object wolffian_tolerantism) {
		ilmenorutileBasehearted(wolffian_tolerantism);
	}
	public void ilmenorutileBasehearted(Object teemless_flaxbush) {
		geodynamicalStubby(teemless_flaxbush);
	}
	public void geodynamicalStubby(Object buttonball_aparejo) {
		postantennalWird(buttonball_aparejo);
	}
	public void postantennalWird(Object hermit_unbordered) {
		incultivationTurkeydom(hermit_unbordered);
	}
	public void incultivationTurkeydom(Object fenite_nadorite) {
		insagacityApiosoma(fenite_nadorite);
	}
	public void insagacityApiosoma(Object metaphosphate_suspirative) {
		ecuadoranChirrupy(metaphosphate_suspirative);
	}
	public void ecuadoranChirrupy(Object imbirussu_agamic) {
		tabbyUnionistic(imbirussu_agamic);
	}
	public void tabbyUnionistic(Object atavi_saccha) {
		ambulateBacillophobia(atavi_saccha);
	}
	public void ambulateBacillophobia(Object hypericum_microcardius) {
		subreferenceRoomthiness(hypericum_microcardius);
	}
	public void subreferenceRoomthiness(Object unfreighted_stablestand) {
		bolboxalisGeez(unfreighted_stablestand);
	}
	public void bolboxalisGeez(Object tical_niggerling) {
		excursionaryByegaein(tical_niggerling);
	}
	public void excursionaryByegaein(Object sarah_proprovincial) {
		percussiveAlpigene(sarah_proprovincial);
	}
	public void percussiveAlpigene(Object peonism_elaeocarpus) {
		oquassaProchordal(peonism_elaeocarpus);
	}
	public void oquassaProchordal(Object chump_interferometer) {
		snubbinessArrhythmical(chump_interferometer);
	}
	public void snubbinessArrhythmical(Object autist_receiptless) {
		bushiTabacosis(autist_receiptless);
	}
	public void bushiTabacosis(Object sunniness_lienteria) {
		choicenessUndergrove(sunniness_lienteria);
	}
	public void choicenessUndergrove(Object euphemious_cubatory) {
		recreantlyGypsyweed(euphemious_cubatory);
	}
	public void recreantlyGypsyweed(Object acadian_klipfish) {
		overbrutalPewit(acadian_klipfish);
	}
	public void overbrutalPewit(Object wearproof_jollytail) {
		albaniaRemutation(wearproof_jollytail);
	}
	public void albaniaRemutation(Object coinhabit_autocratic) {
		shatterwitHandwork(coinhabit_autocratic);
	}
	public void shatterwitHandwork(Object keplerian_stoollike) {
		itacolumiteHeliogravure(keplerian_stoollike);
	}
	public void itacolumiteHeliogravure(Object excursionist_adulterer) {
		tutoriallyRimmer(excursionist_adulterer);
	}
	public void tutoriallyRimmer(Object idiospasm_bicameralism) {
		amphisbaenianFiendism(idiospasm_bicameralism);
	}
	public void amphisbaenianFiendism(Object abaisance_paola) {
		methodisticallyCollectanea(abaisance_paola);
	}
	public void methodisticallyCollectanea(Object sweetsop_unabasedly) {
		unlovelilyInadaptive(sweetsop_unabasedly);
	}
	public void unlovelilyInadaptive(Object outpocketing_uncrossexamined) {
		funderReaward(outpocketing_uncrossexamined);
	}
	public void funderReaward(Object floppiness_extispex) {
		spilusRuberythrinic(floppiness_extispex);
	}
	public void spilusRuberythrinic(Object reapproval_clacker) {
		sackageHoistman(reapproval_clacker);
	}
	public void sackageHoistman(Object spleenless_ovatocordate) {
		stretIrreflection(spleenless_ovatocordate);
	}
	public void stretIrreflection(Object teju_frameableness) {
		vellumPerjurymonger(teju_frameableness);
	}
	public void vellumPerjurymonger(Object enigmatic_leatherworking) {
		chytridiaceaeBreadstuff(enigmatic_leatherworking);
	}
	public void chytridiaceaeBreadstuff(Object gest_peritoneoclysis) {
		spondiasTrilemma(gest_peritoneoclysis);
	}
	public void spondiasTrilemma(Object terrible_cesspit) {
		expellableAttitudinize(terrible_cesspit);
	}
	public void expellableAttitudinize(final Object monomerous_capomo) {
		Tracer.tracepointWeaknessStart("CWE023", "A", "Relative Path Traversal");
		java.io.BufferedReader reader = null;
		String valueString = ((String) monomerous_capomo).trim();
		Tracer.tracepointVariableString("value", ((String) monomerous_capomo));
		Tracer.tracepointVariableString("valueString", valueString);
		if (valueString.length() != 0) {
			Tracer.tracepointMessage("CROSSOVER-POINT: BEFORE");
			File readPath = new File(valueString);
			Tracer.tracepointVariableString("readPath.getPath()",
					readPath.getPath());
			Tracer.tracepointMessage("CROSSOVER-POINT: AFTER");
			Tracer.tracepointMessage("TRIGGER-POINT: BEFORE");
			if (readPath.isFile()) {
				try {
					java.io.FileInputStream fis = new java.io.FileInputStream(
							readPath);
					reader = new java.io.BufferedReader(
							new java.io.InputStreamReader(fis));
					Tracer.tracepointMessage("File opened");
					String line;
					while ((line = reader.readLine()) != null) {
						AbsLexer.entombmentTeutophobia.println(line);
					}
				} catch (java.io.FileNotFoundException e) {
					Tracer.tracepointError(e.getClass().getName() + ": "
							+ e.getMessage());
					AbsLexer.entombmentTeutophobia.printf(
							"File \"%s\" does not exist\n", readPath.getPath());
				} catch (java.io.IOException ioe) {
					Tracer.tracepointError(ioe.getClass().getName() + ": "
							+ ioe.getMessage());
					AbsLexer.entombmentTeutophobia
							.println("Failed to read file.");
				} finally {
					try {
						if (reader != null) {
							reader.close();
						}
					} catch (java.io.IOException e) {
						AbsLexer.entombmentTeutophobia
								.println("STONESOUP: Closing file quietly.");
					}
				}
			} else {
				Tracer.tracepointMessage("File does not exist");
				AbsLexer.entombmentTeutophobia.printf(
						"File \"%s\" does not exist\n", readPath.getPath());
			}
			Tracer.tracepointMessage("TRIGGER-POINT: AFTER");
		}
		Tracer.tracepointWeaknessEnd();
	}
}
